package com.dedsafio.launcher

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.view.View
import android.widget.*

const val ORANGE = 0xFFFF8A1F.toInt()
const val GOLD = 0xFFFFD34D.toInt()
const val CARD = 0xFF1A1017.toInt()
const val MC_PKG = "com.mojang.minecraftpe"

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

fun Context.minecraftInstalled(): Boolean = try { packageManager.getPackageInfo(MC_PKG, 0); true } catch (e: Exception) { false }

fun Context.openUrl(url: String) {
    if (!(url.startsWith("https://") || url.startsWith("http://"))) { toast("El enlace no es válido."); return }
    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (e: ActivityNotFoundException) { toast("No hay ninguna app para abrir este enlace.") }
}

fun Context.openMinecraft() {
    val i = packageManager.getLaunchIntentForPackage(MC_PKG)
    if (i == null) toast("Minecraft Bedrock no está instalado en este dispositivo.") else startActivity(i)
}

fun Context.bedrockLink(uri: String) {
    if (!minecraftInstalled()) { toast("Minecraft Bedrock no está instalado en este dispositivo."); return }
    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(MC_PKG)) }
    catch (e: Exception) { toast("Tu versión de Minecraft no admitió el enlace. Añade el servidor manualmente.") }
}

fun Context.label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
    this.text = text; textSize = size; setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
}

fun Context.gameButton(text: String, filled: Boolean = true, onClick: () -> Unit): Button = Button(this).apply {
    this.text = text; setTextColor(if (filled) Color.WHITE else GOLD); textSize = 16f; isAllCaps = true
    typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    val shadow = GradientDrawable().apply {
        setColor(if (filled) 0xFF8A1F0B.toInt() else 0xFF2A1A12.toInt()); cornerRadius = dp(2).toFloat()
    }
    val face = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        if (filled) intArrayOf(0xFFFFB02E.toInt(), 0xFFE8452C.toInt()) else intArrayOf(0xFF2B1B24.toInt(), 0xFF1A1018.toInt())
    ).apply {
        cornerRadius = dp(2).toFloat()
        setStroke(dp(2), if (filled) 0xFFFFE08A.toInt() else ORANGE)
    }
    background = LayerDrawable(arrayOf(shadow, face)).apply { setLayerInset(1, 0, 0, 0, dp(4)) }
    setPadding(dp(8), 0, dp(8), dp(4))
    layoutParams = LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(12) }
    setOnClickListener { onClick() }
}

fun Context.card(vararg views: View): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
    background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(8).toFloat(); setStroke(dp(1), ORANGE) }
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    views.forEach { addView(it) }
}

/** Pantalla base: scroll vertical con título y botón de volver. */
abstract class BaseActivity : Activity() {
    protected lateinit var body: LinearLayout
    protected fun scaffold(title: String, back: Boolean = true) {
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(24), dp(20), dp(32)) }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(body) })
        if (back) body.addView(label("‹ VOLVER", 14f, GOLD, true).apply { setPadding(0, 0, 0, dp(12)); setOnClickListener { finish() } })
        if (title.isNotEmpty()) body.addView(label(title, 26f, Color.WHITE, true))
    }
}
