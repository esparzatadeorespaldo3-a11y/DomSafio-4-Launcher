package com.dedsafio.launcher

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar

/** Pantalla negra "Abriendo Minecraft" con círculo girando y logo. Se cierra sola cuando Minecraft pasa al frente. */
class LoadingActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var launched = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
        }
        root.addView(pic(R.drawable.logo_domsafio, (dm.widthPixels * 0.7f).toInt()))
        root.addView(ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(GOLD)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { topMargin = dp(32) }
        })
        root.addView(label("Abriendo Minecraft…", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        })
        setContentView(root)

        if (!minecraftInstalled()) {
            toast("Minecraft Bedrock no está instalado en este dispositivo.")
            finish()
            return
        }
        handler.postDelayed({ launchMinecraft() }, 1200)
        // Si pasados 10 s seguimos aquí, Minecraft no se abrió
        handler.postDelayed({
            if (!isFinishing) { toast("No se pudo abrir Minecraft."); finish() }
        }, 10000)
    }

    private fun launchMinecraft() {
        val c = Config(this)
        try {
            if (c.serverConfigured) {
                val uri = "minecraft://connect/?serverUrl=${Uri.encode(c.host)}&serverPort=${c.port}"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(MC_PKG))
            } else {
                // Sin servidor configurado: solo abre Minecraft, sin conectar a nada
                val i = packageManager.getLaunchIntentForPackage(MC_PKG)
                if (i != null) startActivity(i)
            }
            launched = true
        } catch (e: Exception) {
            val i = packageManager.getLaunchIntentForPackage(MC_PKG)
            if (i != null) { startActivity(i); launched = true }
            else { toast("No se pudo abrir Minecraft."); finish() }
        }
    }

    override fun onStop() {
        super.onStop()
        if (launched) finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
