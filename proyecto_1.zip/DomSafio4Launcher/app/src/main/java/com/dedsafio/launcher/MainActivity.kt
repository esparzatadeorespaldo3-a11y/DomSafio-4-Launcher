package com.dedsafio.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.VideoView

class MainActivity : Activity() {
    private lateinit var video: VideoView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val dm = resources.displayMetrics
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // Fondo: video en bucle, sin sonido, recortado para cubrir toda la pantalla
        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            val vw = mp.videoWidth.toFloat()
            val vh = mp.videoHeight.toFloat()
            if (vw > 0f && vh > 0f) {
                val sc = maxOf(dm.widthPixels / vw, dm.heightPixels / vh) * 1.06f
                video.layoutParams = FrameLayout.LayoutParams((vw * sc).toInt(), (vh * sc).toInt(), Gravity.CENTER)
            }
            video.start()
        }
        video.setOnErrorListener { _, _, _ -> true }
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.fondo}"))
        root.addView(View(this).apply { setBackgroundColor(0x33000000) }, FrameLayout.LayoutParams(-1, -1))

        // Contenido
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(36), dp(16), dp(24))
        }
        col.addView(pic(R.drawable.logo_domsafio, (dm.widthPixels * 0.84f).toInt()))
        col.addView(pic(R.drawable.logo_novax, (dm.widthPixels * 0.5f).toInt()))
        col.addView(View(this), LinearLayout.LayoutParams(1, dp(28)))
        val bw = (dm.widthPixels * 0.62f).toInt()
        fun btn(res: Int, desc: String, action: () -> Unit) {
            col.addView(pic(res, bw).apply {
                contentDescription = desc
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(8)
                pressable(action)
            })
        }
        btn(R.drawable.btn_jugar, "Jugar") { startActivity(Intent(this@MainActivity, LoadingActivity::class.java)) }
        btn(R.drawable.btn_salir, "Salir") { finishAffinity() }
        btn(R.drawable.btn_opciones, "Opciones") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }

        root.addView(ScrollView(this).apply { isFillViewport = true; addView(col) }, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); video.start() }
    override fun onPause() { super.onPause(); video.pause() }
}
