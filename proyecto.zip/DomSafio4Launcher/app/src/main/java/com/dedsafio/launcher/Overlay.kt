package com.dedsafio.launcher

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar

/** Pantalla de carga negra que se dibuja ENCIMA de Minecraft (permiso "Mostrar sobre otras apps"). */
object Overlay {
    private var view: View? = null
    private val handler = Handler(Looper.getMainLooper())

    fun canShow(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun show(app: Context, seconds: Int): Boolean {
        hide(app)
        val ctx = app.applicationContext
        return try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val dm = ctx.resources.displayMetrics
            val unit = minOf(dm.widthPixels, dm.heightPixels).toFloat()

            val frame = FrameLayout(ctx).apply { setBackgroundColor(Color.BLACK) }
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            col.addView(ctx.pic(R.drawable.logo_domsafio, (unit * 0.75f).toInt()))
            col.addView(ProgressBar(ctx).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(GOLD)
                layoutParams = LinearLayout.LayoutParams(ctx.dp(56), ctx.dp(56)).apply { topMargin = ctx.dp(20) }
            })
            col.addView(ctx.label("Abriendo Minecraft…", 18f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, ctx.dp(12), 0, 0)
            })
            frame.addView(col, FrameLayout.LayoutParams(-1, -1))
            frame.addView(ctx.label("OCULTAR ✕", 14f, 0xFFB09A8A.toInt(), true).apply {
                setPadding(ctx.dp(20), ctx.dp(14), ctx.dp(20), ctx.dp(14))
                setOnClickListener { hide(ctx) }
            }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.OPAQUE
            )
            wm.addView(frame, lp)
            view = frame
            handler.postDelayed({ hide(ctx) }, seconds * 1000L)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide(app: Context) {
        handler.removeCallbacksAndMessages(null)
        val v = view ?: return
        view = null
        try {
            (app.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) { }
    }
}

fun Context.openOverlaySettings() {
    try {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    } catch (e: Exception) {
        toast("No se pudieron abrir los ajustes de permisos.")
    }
}
