package com.dedsafio.launcher

import android.content.Context

/** Datos del servidor. Todo está vacío hasta que el propietario lo configure. */
class Config(ctx: Context) {
    private val p = ctx.getSharedPreferences("ded_config", Context.MODE_PRIVATE)
    var host: String
        get() = p.getString("host", "") ?: ""
        set(v) { p.edit().putString("host", v.trim()).apply() }
    var port: String
        get() = p.getString("port", "") ?: ""
        set(v) { p.edit().putString("port", v.trim()).apply() }
    var version: String
        get() = p.getString("version", "") ?: ""
        set(v) { p.edit().putString("version", v.trim()).apply() }
    var discord: String
        get() = p.getString("discord", "") ?: ""
        set(v) { p.edit().putString("discord", v.trim()).apply() }
    var addon: String
        get() = p.getString("addon", "") ?: ""
        set(v) { p.edit().putString("addon", v.trim()).apply() }
    var loading: String
        get() = p.getString("loading", "") ?: ""
        set(v) { p.edit().putString("loading", v.trim()).apply() }
    val loadingSeconds: Int get() = loading.toIntOrNull()?.coerceIn(5, 120) ?: 20
    val serverConfigured: Boolean get() = host.isNotEmpty() && port.toIntOrNull() in 1..65535
}

/** Contenido editable de Novedades y Reglas (aún sin publicar: no se inventa nada). */
object Content {
    val news = listOf("Aún no hay novedades publicadas.\nLos anuncios oficiales de DomSafío 4 aparecerán aquí.")
    val rules = listOf("Las reglas del servidor todavía no han sido publicadas.\nSe mostrarán aquí cuando el propietario (Dominickros344) las defina.")
}
