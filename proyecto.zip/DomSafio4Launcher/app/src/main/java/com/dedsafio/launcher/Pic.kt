package com.dedsafio.launcher

import android.content.Context
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.LinearLayout

fun Context.pic(res: Int, widthPx: Int): ImageView = ImageView(this).apply {
    setImageResource(res)
    adjustViewBounds = true
    layoutParams = LinearLayout.LayoutParams(widthPx, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        gravity = Gravity.CENTER_HORIZONTAL
    }
}

fun ImageView.pressable(onClick: () -> Unit) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
        }
        false
    }
    setOnClickListener { onClick() }
}
