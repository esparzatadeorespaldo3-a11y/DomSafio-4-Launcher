package com.dedsafio.launcher

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout

class MainActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        scaffold("", back = false)
        body.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo_domsafio)
            adjustViewBounds = true
            maxHeight = dp(210)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        })
        body.addView(label("LAUNCHER", 16f, GOLD, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.5f; setPadding(0, 0, 0, dp(16)) })
        body.addView(gameButton("Jugar ahora") { startActivity(Intent(this, PlayActivity::class.java)) })
        body.addView(gameButton("Novedades", false) { text("Novedades", Content.news) })
        body.addView(gameButton("Reglas", false) { text("Reglas", Content.rules) })
        body.addView(gameButton("Comunidad", false) {
            val d = Config(this).discord
            if (d.isEmpty()) toast("El Discord aún no está configurado.") else openUrl(d)
        })
        body.addView(gameButton("Descargar addon", false) {
            val a = Config(this).addon
            if (a.isEmpty()) toast("El enlace del addon aún no está configurado.") else openUrl(a)
        })
        body.addView(gameButton("Información del servidor", false) { startActivity(Intent(this, InfoActivity::class.java)) })
        body.addView(gameButton("Ajustes", false) { startActivity(Intent(this, SettingsActivity::class.java)) })
        body.addView(label("Propietario: Dominickros344", 12f, 0xFFB09A8A.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(24), 0, dp(8)) })
        body.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo_novax)
            adjustViewBounds = true
            maxHeight = dp(70)
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        })
    }
    private fun text(t: String, items: List<String>) =
        startActivity(Intent(this, TextActivity::class.java).putExtra("title", t).putStringArrayListExtra("items", ArrayList(items)))
}
