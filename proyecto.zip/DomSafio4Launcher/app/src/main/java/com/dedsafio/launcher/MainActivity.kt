package com.dedsafio.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView

class MainActivity : Activity() {
    private lateinit var video: VideoView
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        immersive()
        val m = realMetrics()
        val w = m.widthPixels
        val h = m.heightPixels
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // Fondo: video en bucle, sin sonido, cubriendo toda la pantalla (el video ya trae el logo DomSafío 4 y Novax)
        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        val cover = View(this).apply { setBackgroundColor(Color.BLACK) }
        var revealed = false
        fun reveal() {
            if (!revealed) { revealed = true; cover.animate().alpha(0f).setDuration(700).start() }
        }
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            val vw = mp.videoWidth.toFloat()
            val vh = mp.videoHeight.toFloat()
            if (vw > 0f && vh > 0f) {
                val sc = maxOf(w / vw, h / vh)
                video.layoutParams = FrameLayout.LayoutParams((vw * sc).toInt() + 2, (vh * sc).toInt() + 2, Gravity.CENTER)
            }
            mp.setOnInfoListener { _, what, _ ->
                if (what == android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) reveal()
                true
            }
            video.start()
        }
        video.setOnErrorListener { _, _, _ -> reveal(); true }
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.fondo}"))
        Handler(Looper.getMainLooper()).postDelayed({ reveal() }, 1500)

        // Degradado inferior suave para que los textos se lean
        root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0x99000000.toInt(), 0x00000000))
        }, FrameLayout.LayoutParams(-1, (h * 0.25f).toInt(), Gravity.BOTTOM))
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))

        // Botones bajo el logo (a la izquierda), como en la referencia
        val bw = (w * 0.20f).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val buttons = ArrayList<View>()
        fun btn(res: Int, desc: String, action: () -> Unit) {
            val v = pic(res, bw).apply {
                contentDescription = desc
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(6)
                pressable(action)
            }
            buttons.add(v)
            col.addView(v)
        }
        btn(R.drawable.btn_jugar, "Jugar") { play() }
        btn(R.drawable.btn_salir, "Salir") { finishAffinity() }
        btn(R.drawable.btn_opciones, "Opciones") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        root.addView(col, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = (w * 0.175f - bw / 2f).toInt()
            bottomMargin = (h * 0.07f).toInt()
        })
        buttons.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(500L + i * 140L).setDuration(500).start()
        }

        // Estado del servidor (arriba a la derecha) y versión (abajo a la derecha)
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(0xAA000000.toInt()); cornerRadius = dp(20).toFloat(); setStroke(dp(1), 0x66FFFFFF)
            }
        }
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(16); rightMargin = dp(24)
        })
        root.addView(label("DomSafío 4 Launcher  ·  v1.0", 11f, 0xCCFFFFFF.toInt()).apply {
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            bottomMargin = dp(10); rightMargin = dp(24)
        })
        setContentView(root)
    }

    private fun updateStatus() {
        val c = Config(this)
        val dot = if (c.serverConfigured) 0xFFFFC145.toInt() else 0xFF8A8A8A.toInt()
        val t = if (c.serverConfigured) "SERVIDOR  ${c.host}:${c.port}" else "SERVIDOR  SIN CONFIGURAR"
        status.text = SpannableString("●  $t").apply {
            setSpan(ForegroundColorSpan(dot), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun play() {
        if (!minecraftInstalled()) { toast("Minecraft Bedrock no está instalado en este dispositivo."); return }
        if (Overlay.canShow(this) && Overlay.show(this, Config(this).loadingSeconds)) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!launchMinecraft()) { Overlay.hide(this); toast("No se pudo abrir Minecraft.") }
            }, 800)
            return
        }
        android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Pantalla de carga sobre Minecraft")
            .setMessage("Para mostrar la pantalla de carga encima de Minecraft, Android necesita el permiso \"Mostrar sobre otras apps\". Es opcional.")
            .setPositiveButton("Dar permiso") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Jugar sin ella") { _, _ -> startActivity(Intent(this, LoadingActivity::class.java)) }
            .show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    override fun onResume() { super.onResume(); updateStatus(); video.start() }
    override fun onPause() { super.onPause(); video.pause() }
}
