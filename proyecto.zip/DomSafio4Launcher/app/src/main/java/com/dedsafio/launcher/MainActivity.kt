package com.dedsafio.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.VideoView

class MainActivity : Activity() {
    private lateinit var video: VideoView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val dm = resources.displayMetrics
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // Fondo: video en bucle, sin sonido, recortado para cubrir toda la pantalla
        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            val vw = mp.videoWidth.toFloat()
            val vh = mp.videoHeight.toFloat()
            if (vw > 0f && vh > 0f) {
                val sc = maxOf(dm.widthPixels / vw, dm.heightPixels / vh) * 1.04f
                video.layoutParams = FrameLayout.LayoutParams((vw * sc).toInt(), (vh * sc).toInt(), Gravity.CENTER)
            }
            video.start()
        }
        video.setOnErrorListener { _, _, _ -> true }
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.fondo}"))
        root.addView(View(this).apply { setBackgroundColor(0x33000000) }, FrameLayout.LayoutParams(-1, -1))

        // Menú a la izquierda (horizontal)
        val u = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(8), dp(28), dp(8))
        }
        col.addView(pic(R.drawable.logo_domsafio, (u * 0.62f).toInt()))
        col.addView(pic(R.drawable.logo_novax, (u * 0.30f).toInt()))
        col.addView(View(this), LinearLayout.LayoutParams(1, dp(10)))
        val bw = (u * 0.42f).toInt()
        fun btn(res: Int, desc: String, action: () -> Unit) {
            col.addView(pic(res, bw).apply {
                contentDescription = desc
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(4)
                pressable(action)
            })
        }
        btn(R.drawable.btn_jugar, "Jugar") { play() }
        btn(R.drawable.btn_salir, "Salir") { finishAffinity() }
        btn(R.drawable.btn_opciones, "Opciones") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }

        root.addView(
            ScrollView(this).apply { isFillViewport = true; addView(col, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL)) },
            FrameLayout.LayoutParams(-2, -1, Gravity.START)
        )
        setContentView(root)
    }

    private fun play() {
        if (!minecraftInstalled()) { toast("Minecraft Bedrock no está instalado en este dispositivo."); return }
        if (Overlay.canShow(this) && Overlay.show(this, Config(this).loadingSeconds)) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!launchMinecraft()) { Overlay.hide(this); toast("No se pudo abrir Minecraft.") }
            }, 800)
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Pantalla de carga sobre Minecraft")
            .setMessage("Para mostrar la pantalla de carga encima de Minecraft, Android necesita el permiso \"Mostrar sobre otras apps\". Es opcional.")
            .setPositiveButton("Dar permiso") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Jugar sin ella") { _, _ -> startActivity(Intent(this, LoadingActivity::class.java)) }
            .show()
    }

    override fun onResume() { super.onResume(); video.start() }
    override fun onPause() { super.onPause(); video.pause() }
}
