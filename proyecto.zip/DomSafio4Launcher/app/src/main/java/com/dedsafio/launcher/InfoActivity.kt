package com.dedsafio.launcher

import android.graphics.Color
import android.os.Bundle

class InfoActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        scaffold("Información del servidor")
        val c = Config(this)
        fun row(k: String, v: String) = card(label(k, 12f, GOLD, true), label(v, 18f, Color.WHITE))
        body.addView(row("ESTADO", if (c.serverConfigured) "Configurado (conexión no verificada)" else "Sin configurar"))
        body.addView(row("DIRECCIÓN IP", c.host.ifEmpty { "Pendiente" }))
        body.addView(row("PUERTO", c.port.ifEmpty { "Pendiente" }))
        body.addView(row("VERSIÓN", c.version.ifEmpty { "Pendiente" }))
    }
}
