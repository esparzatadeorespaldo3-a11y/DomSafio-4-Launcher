package com.dedsafio.launcher

import android.content.Intent
import android.graphics.Color
import android.os.Bundle

class PlayActivity : BaseActivity() {
    override fun onResume() {
        super.onResume()
        scaffold("Jugar ahora")
        val c = Config(this)
        val mc = minecraftInstalled()
        body.addView(card(
            label("MINECRAFT BEDROCK", 12f, GOLD, true),
            label(if (mc) "Instalado" else "No instalado en este dispositivo", 18f, if (mc) Color.WHITE else 0xFFFF6B6B.toInt()),
            label("SERVIDOR", 12f, GOLD, true).apply { setPadding(0, dp(12), 0, 0) },
            label(if (c.serverConfigured) "${c.host}:${c.port}" else "Sin configurar", 18f, Color.WHITE)
        ))
        body.addView(gameButton("Abrir Minecraft") { openMinecraft() })
        body.addView(gameButton("Añadir servidor a Minecraft", false) {
            if (!c.serverConfigured) toast("Primero configura IP y puerto en Ajustes.")
            else bedrockLink("minecraft://?addExternalServer=DomSafio4|${c.host}:${c.port}")
        })
        body.addView(gameButton("Conectar al servidor", false) {
            if (!c.serverConfigured) toast("Primero configura IP y puerto en Ajustes.")
            else bedrockLink("minecraft://connect/?serverUrl=${c.host}&serverPort=${c.port}")
        })
        body.addView(gameButton("Configurar servidor", false) { startActivity(Intent(this, SettingsActivity::class.java)) })
    }
}
