package com.dedsafio.launcher

import android.graphics.Color
import android.os.Bundle

class TextActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        scaffold(intent.getStringExtra("title") ?: "")
        intent.getStringArrayListExtra("items")?.forEach { body.addView(card(label(it, 16f, Color.WHITE))) }
    }
}
