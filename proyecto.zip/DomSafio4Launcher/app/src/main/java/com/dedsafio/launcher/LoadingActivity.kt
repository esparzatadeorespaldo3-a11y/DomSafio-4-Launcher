package com.dedsafio.launcher

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar

/** Alternativa sin permiso de superposición: pantalla negra que se cierra cuando Minecraft pasa al frente. */
class LoadingActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var launched = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val dm = resources.displayMetrics
        val unit = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
        }
        root.addView(pic(R.drawable.logo_domsafio, (unit * 0.75f).toInt()))
        root.addView(ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(GOLD)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { topMargin = dp(20) }
        })
        root.addView(label("Abriendo Minecraft…", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(root)

        if (!minecraftInstalled()) {
            toast("Minecraft Bedrock no está instalado en este dispositivo.")
            finish()
            return
        }
        handler.postDelayed({
            if (launchMinecraft()) launched = true else { toast("No se pudo abrir Minecraft."); finish() }
        }, 1200)
        handler.postDelayed({
            if (!isFinishing) { toast("No se pudo abrir Minecraft."); finish() }
        }, 10000)
    }

    override fun onStop() {
        super.onStop()
        if (launched) finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
