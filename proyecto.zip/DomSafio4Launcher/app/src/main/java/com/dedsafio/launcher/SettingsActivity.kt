package com.dedsafio.launcher

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.EditText

class SettingsActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        scaffold("Ajustes")
        val c = Config(this)
        val uri = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
            this.hint = hint; setText(value); inputType = type
            setTextColor(Color.WHITE); setHintTextColor(0xFF6E6690.toInt()); setSingleLine()
        }
        val host = field("IP o dominio del servidor", c.host, uri)
        val port = field("Puerto (1-65535)", c.port, InputType.TYPE_CLASS_NUMBER)
        val ver = field("Versión de Minecraft", c.version)
        val dis = field("Enlace de Discord (https://...)", c.discord, uri)
        val add = field("Enlace de descarga del addon (https://...)", c.addon, uri)
        body.addView(card(label("SERVIDOR", 12f, GOLD, true), host, port, ver))
        body.addView(card(label("ENLACES", 12f, GOLD, true), dis, add))
        body.addView(gameButton("Guardar") {
            val h = host.text.toString().trim(); val p = port.text.toString().trim()
            val d = dis.text.toString().trim(); val a = add.text.toString().trim()
            when {
                (h.isNotEmpty() || p.isNotEmpty()) && (h.isEmpty() || p.toIntOrNull() !in 1..65535) ->
                    toast("Indica una IP/dominio y un puerto válido (1-65535), o deja ambos vacíos.")
                h.contains(Regex("\\s|/")) -> toast("La IP no debe contener espacios ni \"/\".")
                (d.isNotEmpty() && !d.startsWith("https://")) || (a.isNotEmpty() && !a.startsWith("https://")) ->
                    toast("Los enlaces deben empezar por https://")
                else -> {
                    c.host = h; c.port = p; c.version = ver.text.toString(); c.discord = d; c.addon = a
                    toast("Guardado."); finish()
                }
            }
        })
    }
}
