package com.dedsafio.launcher

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout

class SettingsActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        scaffold("Opciones", wide = true)
        val c = Config(this)
        val uri = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
            this.hint = hint; setText(value); inputType = type
            setTextColor(Color.WHITE); setHintTextColor(0xFF8A7A70.toInt()); setSingleLine()
        }
        val host = field("IP o dominio del servidor", c.host, uri)
        val port = field("Puerto (1-65535)", c.port, InputType.TYPE_CLASS_NUMBER)
        val ver = field("Versión de Minecraft", c.version)
        val dis = field("Enlace de Discord (https://...)", c.discord, uri)
        val add = field("Enlace de descarga del addon (https://...)", c.addon, uri)
        val load = field("Segundos de pantalla de carga (5-120, por defecto 20)", c.loading, InputType.TYPE_CLASS_NUMBER)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row.addView(left, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(10) })
        row.addView(right, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
        body.addView(row)

        left.addView(card(label("SERVIDOR", 12f, GOLD, true), host, port, ver))
        left.addView(card(label("ENLACES", 12f, GOLD, true), dis, add))
        left.addView(card(label("PANTALLA DE CARGA", 12f, GOLD, true), load))

        right.addView(gameButton("Guardar") {
            val h = host.text.toString().trim(); val p = port.text.toString().trim()
            val d = dis.text.toString().trim(); val a = add.text.toString().trim()
            when {
                (h.isNotEmpty() || p.isNotEmpty()) && (h.isEmpty() || p.toIntOrNull() !in 1..65535) ->
                    toast("Indica una IP/dominio y un puerto válido (1-65535), o deja ambos vacíos.")
                h.contains(Regex("\\s|/")) -> toast("La IP no debe contener espacios ni \"/\".")
                (d.isNotEmpty() && !d.startsWith("https://")) || (a.isNotEmpty() && !a.startsWith("https://")) ->
                    toast("Los enlaces deben empezar por https://")
                load.text.toString().trim().isNotEmpty() && load.text.toString().trim().toIntOrNull() !in 5..120 ->
                    toast("Los segundos deben estar entre 5 y 120.")
                else -> {
                    c.loading = load.text.toString()
                    c.host = h; c.port = p; c.version = ver.text.toString(); c.discord = d; c.addon = a
                    toast("Guardado.")
                }
            }
        })
        right.addView(gameButton("Novedades", false) { text("Novedades", Content.news) })
        right.addView(gameButton("Reglas", false) { text("Reglas", Content.rules) })
        right.addView(gameButton("Comunidad", false) {
            val d = Config(this).discord
            if (d.isEmpty()) toast("El Discord aún no está configurado.") else openUrl(d)
        })
        right.addView(gameButton("Descargar addon", false) {
            val a = Config(this).addon
            if (a.isEmpty()) toast("El enlace del addon aún no está configurado.") else openUrl(a)
        })
        right.addView(gameButton("Información del servidor", false) { startActivity(Intent(this, InfoActivity::class.java)) })
        right.addView(gameButton("Permiso: mostrar sobre otras apps", false) { openOverlaySettings() })
    }

    private fun text(t: String, items: List<String>) =
        startActivity(Intent(this, TextActivity::class.java).putExtra("title", t).putStringArrayListExtra("items", ArrayList(items)))
}
