package com.dedsafio.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Abre Minecraft. Con servidor configurado intenta conectar; si no, solo abre Minecraft. */
fun Context.launchMinecraft(): Boolean {
    val c = Config(this)
    return try {
        if (c.serverConfigured) {
            val uri = "minecraft://connect/?serverUrl=${Uri.encode(c.host)}&serverPort=${c.port}"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(MC_PKG))
            true
        } else {
            val i = packageManager.getLaunchIntentForPackage(MC_PKG)
            if (i != null) { startActivity(i); true } else false
        }
    } catch (e: Exception) {
        try {
            val i = packageManager.getLaunchIntentForPackage(MC_PKG)
            if (i != null) { startActivity(i); true } else false
        } catch (e2: Exception) { false }
    }
}
