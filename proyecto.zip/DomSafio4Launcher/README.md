# DomSafío 4 Launcher
Android nativo (Kotlin, minSdk 26). Abrir en Android Studio -> Build > Build APK(s).
Datos pendientes (se configuran en la app, pantalla Ajustes): IP, puerto, versión, Discord, addon.
Novedades y reglas: editar `Content` en Config.kt.
